import { ProjectsearchPipe } from './projectsearch.pipe';

describe('ProjectsearchPipe', () => {
  it('create an instance', () => {
    const pipe = new ProjectsearchPipe();
    expect(pipe).toBeTruthy();
  });
});
