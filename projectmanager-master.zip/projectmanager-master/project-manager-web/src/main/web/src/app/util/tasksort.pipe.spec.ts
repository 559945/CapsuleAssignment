import { TasksortPipe } from './tasksort.pipe';

describe('TasksortPipe', () => {
  it('create an instance', () => {
    const pipe = new TasksortPipe();
    expect(pipe).toBeTruthy();
  });
});
