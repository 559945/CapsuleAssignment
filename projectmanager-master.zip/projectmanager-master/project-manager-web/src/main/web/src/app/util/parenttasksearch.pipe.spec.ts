import { ParenttasksearchPipe } from './parenttasksearch.pipe';

describe('ParenttasksearchPipe', () => {
  it('create an instance', () => {
    const pipe = new ParenttasksearchPipe();
    expect(pipe).toBeTruthy();
  });
});
