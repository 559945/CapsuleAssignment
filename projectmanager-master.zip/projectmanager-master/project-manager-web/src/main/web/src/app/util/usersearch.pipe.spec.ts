import { UsersearchPipe } from './usersearch.pipe';

describe('UsersearchPipe', () => {
  it('create an instance', () => {
    const pipe = new UsersearchPipe();
    expect(pipe).toBeTruthy();
  });
});
