import { ProjecttasksearchPipe } from './projecttasksearch.pipe';

describe('ProjecttasksearchPipe', () => {
  it('create an instance', () => {
    const pipe = new ProjecttasksearchPipe();
    expect(pipe).toBeTruthy();
  });
});
