import { UsersortPipe } from './usersort.pipe';

describe('UsersortPipe', () => {
  it('create an instance', () => {
    const pipe = new UsersortPipe();
    expect(pipe).toBeTruthy();
  });
});
