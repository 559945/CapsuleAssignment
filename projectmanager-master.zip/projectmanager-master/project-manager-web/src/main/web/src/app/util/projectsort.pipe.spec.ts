import { ProjectsortPipe } from './projectsort.pipe';

describe('ProjectsortPipe', () => {
  it('create an instance', () => {
    const pipe = new ProjectsortPipe();
    expect(pipe).toBeTruthy();
  });
});
